package store.product;

public record ProductOut(
    String id,
    String name,
    double price
) {}