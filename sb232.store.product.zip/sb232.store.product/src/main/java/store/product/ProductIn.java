package store.product;

public class ProductIn {
    String name;
    double price;

    public ProductIn(String name, double price) {
        this.name = nome;
        this.price = price;
    }

}
