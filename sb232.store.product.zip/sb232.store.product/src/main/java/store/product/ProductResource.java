package store.product;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ProductResource {

    // Singleton
    static final Map<String, ProductOut> produtos = new HashMap<String, ProductOut>();
    static {
        produtos.put("1", new ProductOut("1", "Sushi", 12));
        produtos.put("2", new ProductOut("2", "Temaki", 20));
    }

    @GetMapping("/product")
    public List<ProductOut> list() {
        return new ArrayList<>(produtos.values());
    }

    @GetMapping("/product/{id}")
    public ProductOut get(@PathVariable(required = true) String id) {
        return produtos.get(id);
    }

    @DeleteMapping("/product/{id}")
    public void delete(@PathVariable(required = true) String id) {
        produtos.remove(id);
    }

    @PostMapping("/product")
    public void create(@RequestBody ProductIn in) {
        final String id = UUID.randomUUID().toString();
        produtos.put(
            id,
            new ProductOut(id, in.name, in.price)
        );
    }



}
