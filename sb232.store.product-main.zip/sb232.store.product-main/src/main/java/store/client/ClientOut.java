package store.client;

public record ClientOut(
    String id,
    String name,
    String cpf,
    String email
) {}